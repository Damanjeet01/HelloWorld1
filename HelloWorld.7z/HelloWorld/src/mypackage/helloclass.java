package mypackage;

public class helloclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("heeelloooooooooooooooo");
	}
}
